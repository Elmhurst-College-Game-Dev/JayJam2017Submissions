﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Checkpoint : MonoBehaviour {

    public Sprite activated;

	// Use this for initialization
	void Start () {
		
	}

    public void Activate() {
        GetComponent<SpriteRenderer>().sprite = activated;
        GetComponent<Animator>().enabled = true;
    }

    // Update is called once per frame
    void Update () {
		
	}
}
