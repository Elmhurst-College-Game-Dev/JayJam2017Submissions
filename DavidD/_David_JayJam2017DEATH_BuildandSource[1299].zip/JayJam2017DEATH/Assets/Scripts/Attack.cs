﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour {

    public Collider2D left;
    public Collider2D mid;
    public Collider2D right;

    void DisableSelf() {
        Destroy(transform.gameObject);
    }

    void EnableLeft() {
        left.enabled = true;
        Invoke("DisableLeft", 0.1f);
    }

    void EnableMid() {
        mid.enabled = true;
        Invoke("DisableMid", 0.3f);
    }

    void EnableRight() {
        mid.enabled = true;
        Invoke("DisableRight", 0.1f);
    }

    void DisableLeft() {
        left.enabled = false;
    }

    void DisableMid() {
        mid.enabled = false;
    }

    void DisableRight() {
        mid.enabled = false;
    }

    void OnCollisionEnter2D(Collision2D coll) {
        if (coll.gameObject.tag == "Enemy")
            coll.gameObject.GetComponent<EnemyController>().Hit();
        if (coll.gameObject.tag == "Boss")
            coll.gameObject.GetComponent<HeartBoss>().Hit();
        if (coll.gameObject.tag == "Grave")
            coll.gameObject.GetComponent<GraveDigger>().Dig();
    }

    // Use this for initialization
    void Start () {
        Invoke("EnableRight", 0.0f);
        Invoke("EnableMid", 0.5f/2);
        Invoke("EnableLeft", 0.75f/2);
        Invoke("DisableSelf", 1.3f/2);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
