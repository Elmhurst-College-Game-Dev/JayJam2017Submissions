﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

    public GameObject target;
    public float zOff;
    public float yOff;
    public float xOff;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //transform.position = transform.up * 5;
        if (target != null) {
            Vector3 pos = target.transform.position + target.transform.right * xOff + target.transform.up * yOff + target.transform.forward * zOff;
            transform.position = Vector3.Slerp(transform.position, pos, 5 * Time.deltaTime);//new Vector3(target.transform.position.x, target.transform.position.y, target.transform.position.z), 5 * Time.deltaTime);
        }
	}
}
