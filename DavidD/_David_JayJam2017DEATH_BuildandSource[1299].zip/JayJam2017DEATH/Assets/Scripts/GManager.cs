﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GManager : MonoBehaviour {
    Vector3 respawnPosition;
    GameObject player;
    // Use this for initialization
    void Awake() {
        Application.targetFrameRate = 60;
    }

    void Start () {
        GetComponent<CanvasRenderer>().GetComponent<Image>().CrossFadeAlpha(0f, 1.0f, false);

        player = GameObject.FindGameObjectWithTag("Player");
        //respawnPosition = player.transform.position;
    }
	
    public void EndGame() {
        print("EndGame Called");
        GetComponent<CanvasRenderer>().GetComponent<Image>().color = new Color(1, 1, 1, 0);
        GetComponent<CanvasRenderer>().GetComponent<Image>().CrossFadeAlpha(1f, 1.0f, false);
        Invoke("Quit", 3f);
    }

    void Quit() {
        print("Quit Called");
        Application.Quit();
    }

	// Update is called once per frame
	void Update () {
        if (Input.GetKey("escape"))
            Quit();
    }
}
