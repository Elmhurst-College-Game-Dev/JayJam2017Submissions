﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeartBoss : MonoBehaviour {

    GameObject player;

    public GameObject artery;
    public GameObject cutArtery;
    public GameObject arteryRight;
    public GameObject cutArteryRight;

    bool done = false;

    // Use this for initialization
    void Start() {
        player = GameObject.FindGameObjectWithTag("Player");
    }


    public void Hit() {
        if (player != null && (player.transform.position - transform.position).x > 0) {
            // player hit right artery
            arteryRight.GetComponent<SpriteRenderer>().enabled = false;
            cutArteryRight.GetComponent<SpriteRenderer>().enabled = true;
        } else {
            // player hit left artery
            artery.GetComponent<SpriteRenderer>().enabled = false;
            cutArtery.GetComponent<SpriteRenderer>().enabled = true;
        }
    }

	// Update is called once per frame
	void Update () {
		if (!done) {
            // if both left and right arteries are not hidden, the end is not here
            if (player != null && (!artery.GetComponent<SpriteRenderer>().enabled && !arteryRight.GetComponent<SpriteRenderer>().enabled)) {
                done = true;
                player.GetComponent<TopDownController>().finalDeath();
            }
        }
	}
}
