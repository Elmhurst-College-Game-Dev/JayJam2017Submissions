﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

    int health = 3;

    Vector3 position;
    Vector3 velocity;

    float curSpeed = 1f;
    float maxSpeed = 3.0f/5;

    bool colliding = false;

    GameObject player;
    Rigidbody2D rb;

    public GameObject corpseObj;

    // Use this for initialization
    void Start() {
        player = GameObject.FindGameObjectWithTag("Player");
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update() {
        float dt = Time.deltaTime;
        if (player != null) {
            if (Vector3.Distance(transform.position, player.transform.position) > 0.15f && Vector3.Distance(transform.position, player.transform.position) < 4)
                velocity = -Vector3.up;
            else
                velocity = Vector3.zero;

            Vector3 dir = player.transform.position - transform.position;
            float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
            Quaternion q = Quaternion.AngleAxis(angle + 90, Vector3.forward);
            transform.rotation = Quaternion.Slerp(transform.rotation, q, Time.deltaTime * 1);

            transform.Translate(curSpeed * velocity * dt);
        }
    }

    void OnCollisionEnter2D(Collision2D coll) {
        // TODO: FIX
        if (!colliding)
            colliding = true;
        if (coll.contacts.Length > 0)
        transform.Translate(coll.contacts[0].normal * Time.deltaTime, Space.World);
    }
    void OnCollisionStay2D(Collision2D coll) {
        // TODO: FIX
        //curSpeed = 0;
        transform.Translate(coll.contacts[0].normal * Time.deltaTime, Space.World);
    }
    void OnCollisionExit2D(Collision2D coll) {
        // TODO: FIX
        if (colliding)
            colliding = false;
    }
    void FixedUpdate() {
        if (curSpeed != 0)
            rb.velocity = curSpeed * velocity * Time.deltaTime;
    }

    void Die() {
        Instantiate(corpseObj, transform.position, transform.rotation);
        enabled = false;
        Destroy(transform.gameObject);
    }

    public void Hit() {
        print("OW");
        health--;
        if (health == 0) Die();
    }
}
