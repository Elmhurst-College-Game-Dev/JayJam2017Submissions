﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GraveDigger : MonoBehaviour {

    public GameObject bottom;
    public GameObject middle;
    public GameObject top;

    public GameObject checkpoint;

	// Use this for initialization
	void Start () {
		
	}

    public void Dig() {
        if (bottom.GetComponent<SpriteRenderer>().enabled)
            bottom.GetComponent<SpriteRenderer>().enabled = false;
        else if (middle.GetComponent<SpriteRenderer>().enabled)
            middle.GetComponent<SpriteRenderer>().enabled = false;
        else {
            top.GetComponent<SpriteRenderer>().enabled = false;
            checkpoint.GetComponent<Checkpoint>().Activate();
            GameObject.FindGameObjectWithTag("Player").GetComponent<TopDownController>().SetRespawnPosition(transform.position - Vector3.up * 0.15f);
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
