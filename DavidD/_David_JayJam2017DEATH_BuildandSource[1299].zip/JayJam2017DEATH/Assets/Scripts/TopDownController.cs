﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopDownController : MonoBehaviour {

    Vector3 respawnPosition;

    Vector3 position;
    Vector3 velocity;

    float curSpeed = 0f;
    float accel = 0.075f/5;
    float maxSpeed = 3.0f/3.5f;
    float rotationSpeed = 0f;
    float maxRotationSpeed = 120f;

    bool colliding = false;

    public GameObject attackObj;
    public GameObject corpseObj;
    public GameObject finalDeathObj;

    Rigidbody2D rb;
    Animator anim;

    // Use this for initialization
    void Start() {
        respawnPosition = transform.position;
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update() {

            float dt = Time.deltaTime;

            if (Input.GetKeyDown("z")) {
                Attack();
            }

            // get input
            velocity.x = Input.GetAxisRaw("Horizontal");
            velocity.y = Input.GetAxisRaw("Vertical");

            // handle acceleration
            if (velocity.y > 0 && curSpeed < maxSpeed) {
                curSpeed += accel;
                if (curSpeed > maxSpeed)
                    curSpeed = maxSpeed;
            }
            else if (velocity.y < 0 && curSpeed > -maxSpeed) {
                curSpeed -= accel;
                if (curSpeed < -maxSpeed)
                    curSpeed = -maxSpeed;
            }
            else { // deccellerate
                if (curSpeed > accel) curSpeed -= 1.5f * accel;
                if (curSpeed < accel) curSpeed += 1.5f * accel;
                if (Mathf.Abs(curSpeed) <= 5 * accel) curSpeed = 0;
            }

            // handle rotation
            if (velocity.x > 0 && rotationSpeed < maxRotationSpeed) {
                rotationSpeed += maxRotationSpeed * dt;
                if (rotationSpeed > maxRotationSpeed)
                    rotationSpeed = maxRotationSpeed;
            }
            else if (velocity.x < 0 && rotationSpeed > -maxRotationSpeed) {
                rotationSpeed -= maxRotationSpeed * dt;
                if (rotationSpeed < -maxRotationSpeed)
                    rotationSpeed = -maxRotationSpeed;
            }
            else { // deccellerate
                if (rotationSpeed > maxRotationSpeed * dt) rotationSpeed -= maxRotationSpeed * dt;
                if (rotationSpeed < maxRotationSpeed * dt) rotationSpeed += maxRotationSpeed * dt;
                if (Mathf.Abs(rotationSpeed) <= 2 * maxRotationSpeed * dt) rotationSpeed = 0;
            }

            if (rotationSpeed != 0)
                transform.Rotate(0, 0, rotationSpeed * -dt, Space.World);

            if (curSpeed != 0 && !colliding) {
                transform.Translate(curSpeed * new Vector3(0, 1, 0) * dt);
                anim.SetBool("isWalking", true);
                transform.Find("Legs").GetComponent<Animator>().SetBool("isWalking", true);
            }
            else {
                anim.SetBool("isWalking", false);
                transform.Find("Legs").GetComponent<Animator>().SetBool("isWalking", false);
            }
        
    }

    void OnCollisionEnter2D(Collision2D coll) {
        if (enabled && coll.gameObject.tag == "Enemy")
            Die();
        // TODO: FIX
        if (!colliding)
            colliding = true;
        transform.Translate(coll.contacts[0].normal * Time.deltaTime, Space.World);
    }
    void OnCollisionStay2D(Collision2D coll) {
        // TODO: FIX
        curSpeed = 0;
        transform.Translate(coll.contacts[0].normal * Time.deltaTime, Space.World);
    }
    void OnCollisionExit2D(Collision2D coll) {
        // TODO: FIX
        if (colliding)
            colliding = false;
    }

    void FixedUpdate() {
        if (curSpeed != 0)
            rb.velocity = curSpeed * new Vector3(0, 1, 0) * Time.deltaTime;
    }

    public void SetRespawnPosition(Vector3 pos) {
        if (respawnPosition != pos) {
            // Play Digging Animation

            // Set respawn position
            respawnPosition.x = pos.x;
            respawnPosition.y = pos.y;
        }
    }

    void Attack() {
        print("Attack");
        Instantiate(attackObj, transform.position + transform.up * 0.15f, transform.rotation);
        anim.SetBool("attack", true);
        Invoke("StopAttackAnim", 1.3f/2);
    }

    void StopAttackAnim() {
        anim.SetBool("attack", false);
    }

    public void finalDeath() {
        Instantiate(finalDeathObj, transform.position, transform.rotation);
        Destroy(transform.gameObject);
        Invoke("End", 2);
        enabled = false;
    }

    void End() {
        print("End called");
        GameObject.FindGameObjectWithTag("Finish").GetComponent<GManager>().EndGame();
    }


    void Die() {
        // Play Dying Animation
        enabled = false;
        Instantiate(corpseObj, transform.position, transform.rotation);
        // Fade out

        // Respawn player
        Invoke("Respawn", 0.75f);
    }

    void Respawn() {
        // Reset player
        enabled = true;
        transform.position = respawnPosition;
        transform.rotation = Quaternion.identity;
        
        // Fade in
    }
}
