﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DirectionalMovement : MonoBehaviour {

    // public float speed = 10f;
    public float jumpForce = 10f;
    public Rigidbody rb;
    public GameObject startObject;
    //public Rigidbody startObjectRb;

    //public Text jumpText;
    public Text jumpText;
    public Text messageText;
    public float turnSpeed = 1000f;
    public float accellerateSpeed = 1000f;
    private Vector3 moveDirection;
    private bool jumpedRecently = false;
    public float jumpTime;
    private Quaternion startFacingDirection;

    public GameObject level01;
    public GameObject level02;
    public int currentLevel;

    void Start() {
        rb = GetComponent<Rigidbody>();
        startObject = GameObject.FindWithTag("Start");
        jumpText.text = "Jump Ready";
        messageText.text = "You've been dead for awhile now but todays the big day; your funeral! Best not to be late!";
        // startObjectRb = GetComponent<Rigidbody>();
        startFacingDirection = gameObject.transform.rotation;
        currentLevel = 1;
        Invoke("ClearText", 6);
    }


    void Update() {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        rb.AddTorque(0f, h * turnSpeed * Time.deltaTime, 0f);
        rb.AddForce(transform.forward * v * accellerateSpeed * Time.deltaTime);


        if (Input.GetButtonDown("Jump") && jumpedRecently == false) {
            jumpedRecently = true;
            //Invoke("CanJumpAgain", jumpTime);
            rb.velocity = new Vector3(rb.velocity.x, jumpForce, rb.velocity.z);
        }

        if (gameObject.transform.position.y <= -10) {
            gameObject.transform.position = startObject.transform.position;
            gameObject.transform.rotation = startFacingDirection;
            //print("currently at " + gameObject.transform.position.y);
        }

        if (jumpedRecently == true) {
            jumpText.text = "";
        }
        else
            jumpText.text = "Jump Ready";
    }

    void CanJumpAgain() {
        jumpedRecently = false;
    }

    void ClearText() {
        messageText.text = "";
    }

    void OnTriggerEnter(Collider other) {
        //print("collided with " + other);
        if (other.gameObject.CompareTag("Finish")) {
            if (currentLevel == 1) {
                level01.SetActive(false);
                level02.SetActive(true);
                gameObject.transform.position = startObject.transform.position;
                gameObject.transform.rotation = startFacingDirection;
                messageText.text = "Nice! Nexet level...";
                Invoke("ClearText", 3);
                startObject = GameObject.FindWithTag("Start");
            }
            if (currentLevel == 2) {
                level02.SetActive(false);
                messageText.text = "GG you won";
            }
            currentLevel++;
        }
        if (other.gameObject.CompareTag("Platform")) {
            jumpedRecently = false;
            //print("collided with platformtag");
        }

    }

}
