import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;

public class Player extends DrawableEntity implements Collision {
	
	public Player(String img, Point2D loc) {
		super(img, loc);
	}
	
	@Override
	public void think(long delta) {
		Point2D movement = new Point2D(0.0, 0.0);
		
		if(GameManager.holding(GameManager.IN_LEFT)) {
			movement = movement.add(-5.0, 0.0);
		}
		if(GameManager.holding(GameManager.IN_RIGHT)) {
			movement = movement.add(5.0, 0.0);
		}
		if(GameManager.holding(GameManager.IN_UP)) {
			movement = movement.add(0.0, -5.0);
		}
		if(GameManager.holding(GameManager.IN_DOWN)) {
			movement = movement.add(0.0, 5.0);
		}
		super.move(movement);
	}
	
	@Override 
	public Rectangle2D getBoundary() {
		return sprite.getBoundary();
	}
	
	@Override
	public boolean shouldRemove() {
		return false;
	}
}
