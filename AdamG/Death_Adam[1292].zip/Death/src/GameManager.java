import java.util.ArrayList;
import java.util.Iterator;

import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;

public class GameManager {
	
	public static final String IN_LEFT = "a";
	public static final String IN_RIGHT = "d";
	public static final String IN_UP = "w";
	public static final String IN_DOWN = "s";
	
	private long lastFrame;
	private static ArrayList<String> input = new ArrayList<>();
	private ArrayList<BaseEntity> entities = new ArrayList<>();
	private GraphicsContext gc;
	private Font pointFont;
	private Player player;
	private int points = 0;
	private long startTime = System.nanoTime();
	private int numEnemies = 0;
	
	public GameManager(GraphicsContext gc) {
		this.gc = gc;
		lastFrame = System.nanoTime();
		player = new Player("player.png", new Point2D(500.0, 500.0));
		
		Rectangle2D noEnemyZone = new Rectangle2D(player.getLocation().getX() - 200.0, player.getLocation().getY() - 200.0, 400.0, 400.0);
		while(entities.size() < 5) {
			Point2D p = new Point2D(32.0 + (Math.random()) * (DeathDriver.WINDOW_WIDTH - 32.0),
									32.0 + ( Math.random()) * (DeathDriver.WINDOW_HEIGHT - 32.0));
			if(!noEnemyZone.contains(p)) {
				entities.add(new BaseEnemy("enemy.png", p));
				numEnemies++;
			}
		}
		
	//	entities.add(new BaseEnemy("enemy.png", new Point2D(100.0, 100.0)));
		pointFont = Font.font("Jokerman", FontWeight.BOLD, 26);
	}
	
	private void createEnemy() {
		Point2D p = new Point2D(32.0 + (Math.random()) * (DeathDriver.WINDOW_WIDTH - 64.0),
				32.0 + ( Math.random()) * (DeathDriver.WINDOW_HEIGHT - 64.0));
		entities.add(new BaseEnemy("enemy.png", p));
		numEnemies++;
	}
	
	public long getLastFrame() {
		return lastFrame;
	}
	
	public static boolean holding(String key) {
		return input.contains(key);
	}
	
	public void addInput(String key) {
		if(!input.contains(key)) {
			input.add(key);
		}
	}
	
	public void removeInput(String key) {
		input.remove(key);
	}
	
	public void think(long time) {
		// TODO: Make movement based off delta time.
		long delta = time - lastFrame;
		
		player.think(delta);
		
		Iterator<BaseEntity> itr = entities.iterator();
		ArrayList<BaseEntity> toAdd = new ArrayList<>();
		while(itr.hasNext()) {
			BaseEntity ent = itr.next();
			ent.think(delta);
			
			if(ent instanceof BaseEnemy) {
				BaseEnemy enemy = (BaseEnemy) ent;
				if(enemy.intersects(player))
				{
					enemy.touch();
					points += enemy.getWorth();
				}
			}
			
			if(ent.shouldRemove()) {
				
				// TODO: Once we have kill-able things, add ghosts that float up.
				itr.remove();
				
				if(ent instanceof BaseEnemy) {
					toAdd.add(new Ghost("ghost.png", ent.getLocation()));
					numEnemies--;
				}
				
				continue;
			}
			
			if(ent instanceof Drawable) {
				((Drawable) ent).render(gc);
			}
		}
		
		for(BaseEntity ent : toAdd) {
			entities.add(ent);
		}
		
		toAdd.clear();
		
		if(numEnemies < 5) {
			if(Math.random() < 0.2) {
				this.createEnemy();
			}
		}
		
		player.render(gc);
		
		gc.setFill(Color.RED);
		gc.setStroke(Color.BLACK);
		gc.setLineWidth(2.0);
		gc.setFont(pointFont);
		gc.setTextAlign(TextAlignment.LEFT);
	//	points++;
		StringBuilder hudPoints = new StringBuilder("Points: ");
		for(int i = 10; i < 10000; i *= 10) {
			if(points < i) {
				hudPoints.append(" ");
			}
		}
		hudPoints.append(points);
		gc.fillText(hudPoints.toString(), 1100.0, 25.0);
		
		int seconds = (int) Math.floor((time - startTime) / 1E9) % 60;
		int minutes  = (int) Math.floor((startTime - startTime) / 1E10) % 60;
		
		StringBuilder hudTime = new StringBuilder();
		hudTime.append((minutes >= 10 ? "" : "0") + Integer.toString(minutes) +
						":" + (seconds >= 10 ? "" : "0") + Integer.toString(seconds));
		
		gc.fillText(hudTime.toString(), 18.0, 25.0);
		
		lastFrame = time;
	}
}
