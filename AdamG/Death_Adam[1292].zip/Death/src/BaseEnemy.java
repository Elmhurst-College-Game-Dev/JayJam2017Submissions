import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;

public class BaseEnemy extends DrawableEntity implements Collision {

	private boolean touched = false;
	private long lastChange = 0;
	private Point2D dir = new Point2D(2.0, 0.0);
	
	public BaseEnemy(String image, Point2D location) {
		super(image, location);
	}
	
	public int getWorth() {
		return 5;
	}
	
	public void touch() {
		touched = true;
	}
	
	@Override
	public void think(long delta) {
		lastChange += delta;
		if(lastChange > 16000000 * 120 || !super.canMove(dir)) {
			double x = (Math.random() * 5) * (Math.random() > 0.5 ? 1 : -1);
			double y = (Math.random() * 5) * (Math.random() > 0.5 ? 1 : -1);
			dir = new Point2D(x, y);
			lastChange = 0;
		}
		super.move(dir);
	}

	@Override
	public boolean shouldRemove() {
		return touched;
	}
	
	@Override
	public Rectangle2D getBoundary() {
		return sprite.getBoundary();
	}

}
