import javafx.geometry.Rectangle2D;

public interface Collision {
	
	public default boolean shouldCollide() {
		return true;
	}
	
	public Rectangle2D getBoundary();
	
	public default boolean intersects(Collision c) {
		return shouldCollide() && c.shouldCollide() && getBoundary().intersects(c.getBoundary());
	}
	
	public default boolean intersects(Rectangle2D rect) {
		return shouldCollide() && getBoundary().intersects(rect);
	}
}
