import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;

public abstract class DrawableEntity extends BaseEntity implements Drawable {
	protected Sprite sprite;
	
	public DrawableEntity(String img, Point2D loc) {
		sprite = new Sprite(img, loc);
	}
	
	@Override
	public void render(GraphicsContext gc) {
		sprite.render(gc);
	}
	
	public boolean canMove(Point2D dir) {
		Rectangle2D rect = sprite.getBoundary();
		
		
		rect = new Rectangle2D(rect.getMinX() + dir.getX(),
								rect.getMinY() + dir.getY(),
								rect.getWidth(),
								rect.getHeight());
		/*Rectangle2D window = new Rectangle2D(0.0 - (rect.getWidth() / 2.0), 0.0 - (rect.getHeight() / 2.0), 
											(double) DeathDriver.WINDOW_WIDTH, 
											(double) DeathDriver.WINDOW_HEIGHT); */
		Rectangle2D window = new Rectangle2D(0.0, 0.0, (double) DeathDriver.WINDOW_WIDTH, (double) DeathDriver.WINDOW_HEIGHT);
		return window.contains(rect);
	}
	
	public boolean move(Point2D dir) {
		if(canMove(dir)) {
			sprite.move(dir);
			return true;
		}
		return false;
	}
	
	@Override
	public Point2D getLocation() {
		return sprite.getLocation();
	}
	
	public void setLocation(Point2D loc) {
		sprite.setLocation(loc);
	}
}
