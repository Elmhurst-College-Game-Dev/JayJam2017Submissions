import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Sprite implements Drawable {
	
	private Image img;
	private Point2D location;
	
	public Sprite(String image, Point2D loc) {
		img = new Image(image);
		location = new Point2D(loc.getX(), loc.getY());
	}
	
	public void render(GraphicsContext gc) {
		gc.drawImage(img, location.getX(), location.getY());
	}
	
	public void move(Point2D dir) {
		location = location.add(dir);
	}
	
	public void setLocation(Point2D loc) {
		location = new Point2D(loc.getX(), loc.getY());
	}
	
	public Point2D getLocation() {
		return location;
	}
	
	public Rectangle2D getBoundary() {
		double height = img.getHeight();
		double width = img.getWidth();
		double topLeftX = location.getX() - (width / 2.0);
		double topLeftY = location.getY() - (height / 2.0);
		Rectangle2D rect = new Rectangle2D(topLeftX, topLeftY, width, height);
		return rect;
	}
}