import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

public class DeathDriver extends Application {

	public static final int WINDOW_WIDTH = 1280;
	public static final int WINDOW_HEIGHT = 720;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("death");
		primaryStage.setResizable(false);
		Group root = new Group();
		Scene s = new Scene(root);
		primaryStage.setScene(s);
		
		Canvas c = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
		root.getChildren().add(c);
		
		GraphicsContext gc = c.getGraphicsContext2D();
		
		GameManager gm = new GameManager(gc);
		
		s.addEventHandler(KeyEvent.KEY_PRESSED, (KeyEvent e) -> {
			gm.addInput(e.getText().toLowerCase());
		});
		
		s.addEventHandler(KeyEvent.KEY_RELEASED, (KeyEvent e) -> {
			gm.removeInput(e.getText().toLowerCase());
		});
		
		
		new AnimationTimer() {
			public void handle(long time) {
				// Only render every 0.016 seconds
				if(time - gm.getLastFrame() >= 16000000) { 
					gc.clearRect(0, 0, 1280, 720);
					gm.think(time);
				}
			}
		}.start();
		
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
