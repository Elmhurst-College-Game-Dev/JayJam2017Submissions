import javafx.geometry.Point2D;

public abstract class BaseEntity {
	
	public abstract Point2D getLocation();
	
	/*
	 * Called every time the entity is "thinking", which should be about 60 times per second.
	 * Delta = time since last frame.
	 */
	public abstract void think(long delta);
	
	public abstract boolean shouldRemove();
}
