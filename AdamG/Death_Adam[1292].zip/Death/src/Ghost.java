import javafx.geometry.Point2D;

public class Ghost extends DrawableEntity {

	private Point2D direction = new Point2D(-5.0, -2.0);
	boolean remove = false;
	private double xOffset = 0.0;
	
	public Ghost(String img, Point2D loc) {
		super(img, loc);
	}
	
	@Override
	public void think(long delta) {
		xOffset += 3.14 / 20.0;
		if(xOffset > (3.141 * 2)) {
			xOffset = 0;
		}
		
		double x = getLocation().getX() - Math.sin(xOffset);
		
		super.setLocation(new Point2D(x, getLocation().getY() - 3.0));
		/*
		if(xChange < -42.0) {
			direction = new Point2D(-4.0, -3.0);
		}
		else if(xChange > 42.0) {
			direction = new Point2D(4.0, -3.0);
		}
		*/
		remove = !super.canMove(direction);
	}

	@Override
	public boolean shouldRemove() {
		return remove;
	}

}
